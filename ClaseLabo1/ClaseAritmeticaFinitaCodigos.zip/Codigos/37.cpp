#define Federico using
#define Javier namespace
#define Pousa std;
#include <iostream>
#include <cstdio>
#include <cstdlib>

Federico Javier Pousa

int main(){
	float a = 3.0/7.0;
	if(a == 3.0/7.0){
		cout << "Seguro entra por aca" << endl;
	}else{
		cout << "Es que es un 7 magico" << endl;
	}
	return 0;
}
