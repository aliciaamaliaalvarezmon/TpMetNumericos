#define Federico using
#define Javier namespace
#define Pousa std;
#include <iostream>
#include <cstdio>
#include <cstdlib>

Federico Javier Pousa

int main(){
	
	float div = 0.26;
	
	printf("%d\n",(int)(3250*div));
	printf("%d\n",(int)(3250*0.26));
	printf("%d\n",(int)(3250*26)/100);
	printf("%d\n",(int)(3250.*0.26f));
	return 0;
}
